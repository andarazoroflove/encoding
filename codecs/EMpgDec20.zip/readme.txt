________________________________________________________________________

     ELECARD MPEG 2 Video Decoder Package release 2.0 
	Copyright (C) Moonlight Cordless Corporation 2001-2003
	   Technology Licensed from Elecard Inc.
	    Copyright (C) 1996-2000 Elecard Inc.
	           All Rights Reserved. 
________________________________________________________________________

        	     IMPORTANT!

To un/install the Elecard MPEG2 Video Decoder Package, please, do the following:

	Installation:

	o Unzip delivery pack and follow by Wizard.
	o During installation the program copies and registers DirectShow(R) 
	  filters (Elecard MPEG2 Demultiplexer, Elecard MPEG2 Video Decoder, 
	  etc) 
	o After you click "Finish" the DirectShow(R) filters are ready to use 
	  doesn't require rebooting your computer


	Uninstallation:

	o Click "Start"->"Programs"->"Elecard MPEG2 Decoder Package"->"Uninstall 
	  Elecard MPEG2 Decoder Package"->"Uninstall Elecard MPEG2 Decoder 
	  Package 2.0"->Follow instructions
	o During uninstallation all the above-mentioned filters are uninstalled

________________________________________________________________________

Elecard MPEG2 Video Decoder Package now consists of the following DirectShow 
filters: 

	o MPEG SS/PS/TS/PVA Demultiplexer. Version 2.0 (build 80.30327)
	o Audio Layer 1/2/3/LPCM Decoder, aka OdioDekoda  Version 1.25m
	o Elecard MPEG2 Video Decoder itself. Version 2.0 (build 2510) 
	o DivX div3/div4/mp43/mpg4 Video Decoder, aka NicePheratu. 
	  Version 1.0 Beta (build 67.030313) 


Elecard MPEG2 Demultiplxer is a pull-mode splitter filter 

FEATURES
	o Splits MPEG-2 (ISO/IEC 13818-2) Transport streams, 
	  MPEG-2 (ISO/IEC 13818-2) Program streams and
	  MPEG-1 (ISO/IEC 11172-2) System Streams to video elementary 
	  and audio elementary streams, 
	o Operates with MPEG-2 (ISO/IEC 13818-2) Video and  
	  MPEG-1 (ISO/IEC 11172-2) Video
	o Instant frame-accurate positioning using index 
	o Configurable seeking modes by PTS or Bit rate
	o DVD Subpicture stream support 
	o Supports IMediaSeeking interface 
	o Dynamic media type changes 

Specifications:
	Elecard MPEG2 Demultiplexer supports all the formats mentioned below. 

	The following input streams are supported:
        
	o MPEG-1 Systems (ISO/IEC 11172-1) 
	o MPEG-2 Program Stream (ISO/IEC 13818-1) 
	o MPEG-2 Transport Stream (ISO/IEC 13818-1) 
	o MPEG-1 Video (ISO/IEC 11172-2) 
	o MPEG-2 Video (ISO/IEC 13818-2)

        The following elementary output streams are supported:
          
	o MPEG-1 Video (ISO/IEC 11172-2) 
	o MPEG-1 Audio (ISO/IEC 11172-3) 
	o MPEG-2 Video (ISO/IEC 13818-2) 
	o MPEG-2 Audio (ISO/IEC 13818-3) 
	o Dolby R AC-3 (ATSC A-52) 
	o DVD Subpicture stream 

Demultiplexer creates one output pin for each elementary stream, 
which was found in input stream


________________________________________________________________________

Odio Dekoda - Universal LPCM/MPEG Audio (Layer 1/2/3) Decoder

	Moonlight Odio Dekoda DirectShow (R) filter enables software-only 
	decoding of MPEG-1/2/2.5 Layer I, II and III (also known as mp3) 
	and LPCM audio streams

Features

	o MPEG-1 Layer I, II and III audio streams decoding (ISO/IEC 11172-3) 
	o Supports MPEG-2 extensions to lower sampling frequencies 
	  (ISO/IEC 13818-3), 
	including unofficial MPEG-2.5 format 
	o Supports LPCM audio streams
	o Decoding MPEG audio streams to 8/16/24 bits


System Requirements

	o Windows 95/98/NT/2000/XP with DirectShow installed 
	  (for Windows NT 4.0 and Windows 95 download DirectX (R) Media Runtime). 
	o 32 MB RAM 
	o 200 KB of free disk space 


What's new since version 1.0

	o Quadro & 5.1 output is now available
	o Adjustable resolution of output audio: 8/16/24 bit
	o S/PDIF output is now available
	o Dithering was added for better sound quality
	o Layer I is now supported
	o LPCM is now supported
	o Minor bugs were fixed


To download and upgrade Moonlight Odio Dekoda visit Moonlight Cordless 
	Download page. www.moonlight.co.il/download/

Contact Moonlight for additional information.  info@moonlight.co.il,
	sale@moonlight.co.il or techsupport@elecard.com

________________________________________________________________________

ELECARD MPEG 2 Video Decoder provides software-only
	MPEG 1 and MPEG 2 decoding solution. It is implemented
	as a Microsoft DirectShow filter and could be easily
	incorporated into your editing and playback
	applications.


FEATURES

	o Software-only MPEG-2 (ISO/IEC 13818-2) and MPEG-1 
	  (ISO/IEC 11172-2) video streams decoding for all 
	  profiles/levels, excluding scalability extensions 
	o Full-resolution, full-quality decoding/playback 
	o High precision arithmetics (IEEE 1180-1190 compliant 
	  IDCT, half-pel motion compensation for I,P and B frames) 
	o Optimized for the most efficient CPU usage 
	o Supports DirectShow(R) and ActiveMovie(R) interface 
	o DirectShow(R) Multimedia Streaming support 
	o Special decoding quality control and frame capture interface 
	o Software bob deinterlacing

New in version 2.0 

	o Brightness control interface
	o Postprocessing - deblocking
	o Double precision IDCT
	o Decoding quarter resolution for preview mode 


________________________________________________________________________

NicePheratu Decoder

A specially design engine provides such particular feature of the decoder 
as a possibility to process a number of following DivX formats: 
MSMPEG 4 v1, v2, v3 (DivX 3.x); DivX 4.x; XviD. The decoder is implemented 
as a Microsoft(R) DirectShow(R) filter and can be easy incorporated in 
some editing and playback application. In the future, the company is going 
to supply this decoder by postprocessing feature and DivX 5 decoding function. 

FEATURES: 
	o Decodes different formats such as: MSMPEG 4 v1,v2,v3 (DivX 3.x) 
	  DivX 4.x XviD. mp43, AP41, asf files 
	o Deblock - removing of blocking and ringing artifacts. But takes extra CPU
	  power so the video can start jumping
	o Denoise - sometimes adding some noise to a picture may improve visual
	  quality. Also takes extra CPU power
	o Special interface for picture grabbing 
	o Supports DirectShow(R) and ActiveMovie(R) interface 
	o Full-resolution, full-quality decoding/playback 
	o Optimized for the most efficient CPU usage 


________________________________________________________________________

SYSTEM REQUIREMENTS

	MMX-enhanced CPU (IntelR Pentium MMX, Pentium II, 
	Celeron, Pentium III, AMDR K6-2, K6-3, Athlon, etc.) 
	WindowsR 95/98/NT/2000/XP with DirectShowR installed 
	(WindowsR NT 4.0 and WindowsR 95 with DirectShow installed). 
	32 MB RAM 
	Any VGA card 
	600 KB of free disk space for filter files 




FEEDBACK

	Visit Moonlight Cordless on WWW at http://moonlight.co.il
	On technical issues contact ELECARD technical support
	by e-mail at techsupp@elecard.com.
	For general information: info@elecard.com.
	For licensing information contact sales@moonlight.co.il


________________________________________________________________________
	
        	     IMPORTANT!

To un/install the Elecard MPEG2 Video Decoder Package, please, do the following:

	Installation:

	o Unzip delivery pack and follow by Wizard.
	o During installation the program copies and registers DirectShow(R) 
	  filters (Elecard MPEG2 Demultiplexer, Elecard MPEG2 Video Decoder, 
	  etc) 
	o After you click "Finish" the DirectShow(R) filters are ready to use 
	  doesn't require rebooting your computer


	Uninstallation:

	o Click "Start"->"Programs"->"Elecard MPEG2 Decoder Package"->"Uninstall 
	  Elecard MPEG2 Decoder Package"->"Uninstall Elecard MPEG2 Decoder 
	  Package 2.0"->Follow instructions
	o During uninstallation all the above-mentioned filters are uninstalled

________________________________________________________________________